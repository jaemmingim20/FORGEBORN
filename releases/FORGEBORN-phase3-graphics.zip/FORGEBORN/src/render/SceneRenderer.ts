import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

export class SceneRenderer {
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(72, 1, 0.06, 350);
  readonly renderer: THREE.WebGLRenderer;
  private readonly sky: THREE.Mesh;
  private readonly ambient = new THREE.HemisphereLight('#c4e0e6', '#746448', 2.1);
  private readonly sunlight = new THREE.DirectionalLight('#ffdb9c', 3.1);
  private readonly resizeObserver: ResizeObserver;
  private readonly environment: THREE.WebGLRenderTarget;

  constructor(readonly container: HTMLElement) {
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    // The Phase 1 world is static; do not redraw its shadow map every frame.
    this.renderer.shadowMap.autoUpdate = false;
    this.renderer.shadowMap.needsUpdate = true;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    const room = new RoomEnvironment();
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.environment = pmrem.fromScene(room, 0.04, 0.1, 100, { size: 128 });
    this.scene.environment = this.environment.texture;
    this.scene.environmentIntensity = 0.4;
    room.dispose();
    pmrem.dispose();
    this.renderer.domElement.id = 'game-canvas';
    this.renderer.domElement.setAttribute('aria-label', 'FORGEBORN 1인칭 3D 월드');
    this.container.append(this.renderer.domElement);
    this.scene.background = new THREE.Color('#abb5a7');
    this.scene.fog = new THREE.Fog('#a1aea0', 38, 145);
    const skyMaterial = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        top: { value: new THREE.Color('#365d6e') },
        horizon: { value: new THREE.Color('#e3c79d') },
      },
      vertexShader:
        'varying vec3 vPosition; void main(){ vPosition=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader:
        'varying vec3 vPosition; uniform vec3 top; uniform vec3 horizon; void main(){ float h=normalize(vPosition).y; gl_FragColor=vec4(mix(horizon,top,pow(max(h,0.0),0.55)),1.0);\n#include <tonemapping_fragment>\n#include <colorspace_fragment>\n}',
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(280, 24, 12), skyMaterial);
    this.scene.add(this.sky);
    this.scene.add(this.ambient);
    const sun = this.sunlight;
    sun.position.set(-25, 42, -16);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = sun.shadow.camera.bottom = -43;
    sun.shadow.camera.right = sun.shadow.camera.top = 43;
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 120;
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.045;
    sun.shadow.radius = 2;
    sun.target.position.set(0, 0, -8);
    this.scene.add(sun, sun.target);
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(container);
    this.resize();
  }

  private resize(): void {
    const { width, height } = this.container.getBoundingClientRect();
    if (!width || !height) return;
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  }

  setUnderground(depth: number): void {
    const t = Math.min(1, depth / 12);
    this.ambient.intensity = 2.1 * (1 - t) + 0.7 * t;
    this.sunlight.intensity = 3.1 * (1 - t);
    this.scene.environmentIntensity = 0.4 * (1 - t) + 0.15 * t;
    const fog = this.scene.fog as THREE.Fog;
    fog.color.set('#a1aea0').lerp(new THREE.Color('#111c1e'), t);
    fog.near = 38 * (1 - t) + 6 * t;
    fog.far = 145 * (1 - t) + 35 * t;
  }

  render(): void {
    this.renderer.render(this.scene, this.camera);
  }

  dispose(): void {
    this.resizeObserver.disconnect();
    this.sky.geometry.dispose();
    (this.sky.material as THREE.Material).dispose();
    this.environment.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
