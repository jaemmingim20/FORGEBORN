import RAPIER from '@dimforge/rapier3d-compat';
import { Campaign } from '../campaign/Campaign';
import { CraftingManager } from '../crafting/CraftingManager';
import { CraftingUI } from '../ui/CraftingUI';
import { SmeltingManager } from '../smelting/SmeltingManager';
import type { Furnace } from '../smelting/SmeltingManager';
import type { ItemId } from '../items/data';
import { SmeltingUI } from '../ui/SmeltingUI';
import { InventoryManager } from '../inventory/InventoryManager';
import { MiningManager } from '../mining/MiningManager';
import { generateVeins, mineDepth } from '../mining/data';
import { MiningView } from '../mining/MiningView';
import { MiningUI } from '../ui/MiningUI';
import * as THREE from 'three';
import { EventBus } from './EventBus';
import type { GameState, Vec3 } from './types';
import { InputManager } from '../input/InputManager';
import { FIXED_STEP, PhysicsWorld } from '../physics/PhysicsWorld';
import { PlayerMotor } from '../physics/PlayerMotor';
import { PlayerController } from '../player/PlayerController';
import { SceneRenderer } from '../render/SceneRenderer';
import { UIManager } from '../ui/UIManager';
import { PLAYER_SPAWN } from '../world/data';
import { WorldManager } from '../world/WorldManager';

export interface DebugSnapshot {
  position: Vec3;
  grounded: boolean;
  state: GameState;
  zone: string | null;
  target: string | null;
  yaw: number;
  pitch: number;
  draws: number;
  colliders: number;
}

export interface ForgeDebug {
  snapshot(): DebugSnapshot;
  teleport(position: Vec3): void;
  look(yaw: number, pitch?: number): void;
  fixtureIds(): string[];
  giveItem(item: ItemId, quantity: number): boolean;
  stepSmelting(seconds: number): void;
  smeltingSnapshot(): Furnace[];
  miningSnapshot(): {
    inventory: ReturnType<InventoryManager['snapshot']>;
    veins: Array<{ id: string; ore: string; position: Vec3; remaining: number; depleted: boolean }>;
  };
}

declare global {
  interface Window {
    __forgeDebug?: ForgeDebug;
  }
}

export class GameManager {
  readonly events = new EventBus();
  readonly scene: SceneRenderer;
  readonly world: WorldManager;
  readonly motor: PlayerMotor;
  readonly input: InputManager;
  readonly player: PlayerController;
  readonly ui: UIManager;
  readonly inventory = new InventoryManager(this.events);
  readonly mining = new MiningManager(generateVeins(), this.inventory, this.events);
  readonly smelting = new SmeltingManager(this.inventory, this.events);
  readonly smeltingUI: SmeltingUI;
  readonly crafting = new CraftingManager(this.inventory);
  readonly craftingUI: CraftingUI;
  readonly campaign: Campaign;
  readonly miningView: MiningView;
  readonly miningUI: MiningUI;
  private state: GameState = 'ready';
  private animationFrame = 0;
  private lastTime = performance.now();
  private accumulator = 0;
  private elapsed = 0;
  private disposed = false;
  private readonly direction = new THREE.Vector3();

  static async create(
    container: HTMLElement,
    onError: (error: unknown) => void,
    onProgress?: (message: string) => void,
  ): Promise<GameManager> {
    onProgress?.('물리 엔진을 준비하는 중…');
    const physics = await PhysicsWorld.create();
    try {
      onProgress?.('3D 월드를 만드는 중…');
      return new GameManager(container, physics, onError);
    } catch (error) {
      physics.dispose();
      throw error;
    }
  }

  private constructor(
    container: HTMLElement,
    private readonly physics: PhysicsWorld,
    private readonly onError: (error: unknown) => void,
  ) {
    this.scene = new SceneRenderer(container);
    this.world = new WorldManager(physics, this.events);
    this.scene.scene.add(this.world.root);
    this.motor = new PlayerMotor(physics, PLAYER_SPAWN);
    this.input = new InputManager(
      this.scene.renderer.domElement,
      this.events,
      (locked) => {
        if (locked) this.setState('playing');
        else if (this.state === 'playing') this.setState('paused');
      },
      () => this.ui.toggleMap(),
      {
        inventory: () => this.toggleInventory(),
        equip: () => this.inventory.toggleEquip(),
        attack: () => this.campaign.combat.attack(),
        shortcut: (code) => {
          if (code === 'Digit1') this.campaign.combat.slot = 1;
          if (code === 'Digit2') this.campaign.combat.shield = null;
          if (code === 'Digit3') {
            this.campaign.combat.slot = 3;
            this.inventory.equipped = false;
          }
          if (code === 'KeyM') this.campaign.open('market');
          if (code === 'KeyJ') this.campaign.open('journal');
        },
        interact: () => {
          const kind = this.world.target?.kind;
          if (this.state !== 'playing' || !kind) return;
          if (['counter', 'ledger', 'bed', 'submission'].includes(kind)) {
            this.campaign.open(kind === 'bed' ? 'bed' : kind === 'ledger' ? 'journal' : 'counter');
            return;
          }
          if (kind === 'furnace' && this.world.target?.id !== 'furnace-01') {
            this.campaign.open('furnaces');
            return;
          }
          if (
            ['workbench', 'anvil', 'quench', 'rack'].includes(kind) ||
            (kind === 'furnace' && this.crafting.job?.stage === 'heating')
          ) {
            this.setState('crafting');
            this.craftingUI.open(kind);
            document.exitPointerLock();
          } else if (kind === 'furnace') {
            this.setState('smelting');
            document.exitPointerLock();
          }
        },
      },
    );
    this.player = new PlayerController(this.motor, this.input, this.scene.camera);
    this.ui = new UIManager(container, this.events, {
      enter: () => {
        void this.input.requestLock();
      },
      reset: () => {
        this.player.reset();
        this.input.clear();
      },
      sensitivity: (value) => {
        this.input.sensitivity = value * 0.002;
      },
      headBob: (enabled) => {
        this.player.headBob = enabled;
      },
    });
    this.scene.scene.add(this.scene.camera);
    this.miningView = new MiningView(
      this.mining,
      physics,
      this.scene.camera,
      this.events,
      this.world.materials,
    );
    this.scene.scene.add(this.miningView.root);
    this.miningUI = new MiningUI(container, this.inventory, this.mining, this.events, () =>
      this.toggleInventory(),
    );
    this.smeltingUI = new SmeltingUI(container, this.smelting, this.events, () =>
      this.toggleInventory(),
    );
    this.craftingUI = new CraftingUI(container, this.crafting, () => this.toggleInventory());
    this.events.on('stateChanged', (state) => {
      if (state !== 'crafting') this.craftingUI.hide();
      if (state !== 'campaign') this.campaign?.hide();
    });
    const collectionButton = document.createElement('button');
    collectionButton.textContent = '완성 장비 · 3D 제작 기록 보기';
    collectionButton.addEventListener('click', () => {
      this.setState('crafting');
      this.craftingUI.open('rack');
    });
    this.miningUI.element.querySelector('.inventory-card')?.append(collectionButton);
    this.campaign = new Campaign(this);
    this.crafting.onFinished = (cost) => {
      this.campaign.economy.stats.crafted++;
      this.campaign.economy.stats.parts += cost;
    };
    this.mining.onCollected = (quantity) => {
      this.campaign.economy.stats.mined += quantity;
    };
    this.craftingUI.onManage = () =>
      this.campaign.open(this.world.target?.kind === 'workbench' ? 'workbench' : 'gear');
    this.mining.onHit = () => {
      const c = this.campaign.combat,
        w = c.gear(c.pick);
      c.stamina = Math.max(0, c.stamina - 5);
      if (w) w.durability = Math.max(0, w.durability - 1);
      c.sound(170);
    };
    const link = (parent: HTMLElement | null, label: string, view: string) => {
      const b = document.createElement('button');
      b.className = 'management-link';
      b.textContent = label;
      b.onclick = () => this.campaign.open(view);
      parent?.append(b);
    };
    link(this.miningUI.element.querySelector('.inventory-card'), '장비 장착 / 시장', 'gear');
    link(this.craftingUI.element, '장비 관리 · 분해', 'workbench');
    link(
      this.smeltingUI.element.querySelector('.smelting-card'),
      '용광로 강화 · 증설 · 다중 제련',
      'furnaces',
    );
    this.inventory.notify();
    this.player.headBob = !matchMedia('(prefers-reduced-motion: reduce)').matches;
    const checkbox = this.ui.element.querySelector<HTMLInputElement>('#head-bob');
    if (checkbox) checkbox.checked = this.player.headBob;
    // Populate broad-phase queries before the first frame.
    this.physics.step();
    this.world.zone = null;
    this.world.update(
      this.motor.position,
      this.motor.position,
      { x: 0, y: 0, z: -1 },
      this.motor.collider,
      0,
    );
    this.events.emit('stateChanged', 'ready');
    if (import.meta.env.DEV && new URLSearchParams(location.search).has('debug'))
      this.installDebug();
    this.lastTime = performance.now();
    this.animationFrame = requestAnimationFrame(this.frame);
  }

  mineSwing(): void {
    this.miningView.swing(this.elapsed);
  }
  openCampaign(): void {
    this.setState('campaign');
    document.exitPointerLock();
  }
  resumeGame(): void {
    void this.input.requestLock();
  }
  addFixtureCollider(id: string, center: Vec3, size: Vec3): void {
    this.physics.addBox({ fixtureId: id, center, size });
  }
  physicsRay(origin: Vec3, direction: Vec3, distance: number): boolean {
    return !!this.physics.world.castRay(
      new RAPIER.Ray(origin, direction),
      distance,
      true,
      undefined,
      undefined,
      this.motor.collider,
    );
  }
  private toggleInventory(): boolean {
    if (this.state === 'playing') {
      this.setState('inventory');
      document.exitPointerLock();
      return true;
    }
    if (
      this.state === 'inventory' ||
      this.state === 'smelting' ||
      this.state === 'crafting' ||
      this.state === 'campaign'
    ) {
      void this.input.requestLock();
      return true;
    }
    return false;
  }

  private setState(state: GameState): void {
    if (this.state === state) return;
    this.state = state;
    this.accumulator = 0;
    this.lastTime = performance.now();
    this.input.clear();
    this.events.emit('stateChanged', state);
    if (state === 'playing') this.player.render(1, 0);
    else this.miningView?.cancel();
  }

  private readonly frame = (now: number): void => {
    if (this.disposed) return;
    try {
      const dt = Math.min(Math.max((now - this.lastTime) / 1000, 0), 0.1);
      this.lastTime = now;
      if (this.state === 'playing') {
        this.elapsed += dt;
        this.player.look();
        this.accumulator += dt;
        while (this.accumulator >= FIXED_STEP) {
          this.player.fixedUpdate();
          this.physics.step();
          this.player.afterPhysics();
          this.accumulator -= FIXED_STEP;
        }
        if (this.motor.position.y < -8) this.player.reset();
        this.player.render(this.accumulator / FIXED_STEP, dt);
        this.scene.camera.getWorldDirection(this.direction);
        this.world.update(
          this.motor.position,
          this.scene.camera.position,
          this.direction,
          this.motor.collider,
          this.elapsed,
        );
        this.miningView.update(
          dt,
          this.elapsed,
          this.motor.collider,
          this.campaign.combat.slot === 3,
        );
        this.miningUI.update(
          this.motor.position,
          this.world.zone?.id,
          this.miningView.targetId,
          this.elapsed,
        );
        this.scene.setUnderground(mineDepth(this.motor.position));
        this.ui.update(this.motor.position, this.player.yaw);
      } else if (this.state === 'ready') {
        this.scene.camera.position.set(26, 18, 32);
        this.scene.camera.lookAt(0, 1.5, -8);
        this.world.animate(now / 1000);
      }
      if (this.state !== 'playing')
        this.miningView.update(0, this.elapsed, this.motor.collider, false);
      if (this.state !== 'paused' && this.state !== 'ready') this.smelting.update(dt);
      this.smeltingUI.update(dt);
      this.craftingUI.update(this.state === 'crafting' ? dt : 0);
      this.campaign.update(
        this.state === 'ready' || this.state === 'paused' ? 0 : dt,
        this.state === 'playing',
      );
      this.scene.render();
      this.animationFrame = requestAnimationFrame(this.frame);
    } catch (error) {
      this.dispose();
      this.onError(error);
    }
  };

  private installDebug(): void {
    window.__forgeDebug = {
      snapshot: () => ({
        position: { ...this.motor.position },
        grounded: this.motor.grounded,
        state: this.state,
        zone: this.world.zone?.id ?? null,
        target: this.world.target?.id ?? null,
        yaw: this.player.yaw,
        pitch: this.player.pitch,
        draws: this.scene.renderer.info.render.calls,
        colliders: this.physics.world.colliders.len(),
      }),
      teleport: (position) => {
        this.input.clear();
        this.player.reset(position);
      },
      look: (yaw, pitch = 0) => {
        this.player.yaw = yaw;
        this.player.pitch = pitch;
      },
      fixtureIds: () => [...this.world.fixtures.keys()],
      giveItem: (item, quantity) => this.inventory.add(item, quantity),
      stepSmelting: (seconds) => this.smelting.update(seconds),
      smeltingSnapshot: () => [...this.smelting.furnaces.values()],
      miningSnapshot: () => ({
        inventory: this.inventory.snapshot(),
        veins: [...this.mining.veins.values()].map((v) => ({
          id: v.id,
          ore: v.ore,
          position: v.position,
          remaining: v.remaining,
          depleted: v.depleted,
        })),
      }),
    };
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    cancelAnimationFrame(this.animationFrame);
    this.campaign.dispose();
    this.input.dispose();
    this.ui.dispose();
    this.smeltingUI.dispose();
    this.craftingUI.dispose();
    this.miningUI.dispose();
    this.miningView.dispose();
    this.motor.dispose();
    this.world.dispose();
    this.scene.dispose();
    this.events.dispose();
    this.physics.dispose();
    delete window.__forgeDebug;
  }
}
